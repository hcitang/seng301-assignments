
namespace Frontend1 {
    public interface Deliverable {
    }
}
